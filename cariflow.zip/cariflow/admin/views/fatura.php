<?php
global $wpdb;
$musteri_id = intval($_GET['musteri_id']);
$musteri = $wpdb->get_row("SELECT * FROM {$wpdb->prefix}cariflow_musteriler WHERE id = $musteri_id");
$islemler = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}cariflow_islemler WHERE musteri_id = $musteri_id AND odeme_durumu = 'bekliyor'");
?>

<div class="wrap">
    <h1>Fatura Oluştur: <?= esc_html($musteri->ad . ' ' . $musteri->soyad) ?></h1>
    
    <form method="post" action="<?= admin_url('admin-post.php') ?>">
        <input type="hidden" name="action" value="cariflow_fatura_olustur">
        <input type="hidden" name="musteri_id" value="<?= $musteri_id ?>">
        
        <table class="wp-list-table widefat fixed striped">
            <thead>
                <tr>
                    <th>Seç</th>
                    <th>Tarih</th>
                    <th>Açıklama</th>
                    <th>Tutar</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($islemler as $islem): ?>
                <tr>
                    <td><input type="checkbox" name="islemler[]" value="<?= $islem->id ?>" checked></td>
                    <td><?= date('d.m.Y', strtotime($islem->tarih)) ?></td>
                    <td><?= esc_html($islem->aciklama) ?></td>
                    <td><?= number_format($islem->tutar, 2) ?> TL</td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        
        <button type="submit" class="button button-primary">PDF Oluştur</button>
    </form>
</div>