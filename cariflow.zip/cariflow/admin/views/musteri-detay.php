<?php
global $wpdb;
$musteri_id = intval($_GET['id']);
$musteri = $wpdb->get_row($wpdb->prepare(
    "SELECT * FROM {$wpdb->prefix}cariflow_musteriler WHERE id = %d", 
    $musteri_id
));
$islemler = $wpdb->get_results($wpdb->prepare(
    "SELECT * FROM {$wpdb->prefix}cariflow_islemler WHERE musteri_id = %d ORDER BY tarih DESC",
    $musteri_id
));
?>
<div class="wrap">
    <h1><?= esc_html($musteri->ad.' '.$musteri->soyad) ?> - Detay</h1>
    
    <div class="card">
        <h3>Müşteri Bilgileri</h3>
        <p><strong>Telefon:</strong> <?= esc_html($musteri->telefon) ?></p>
        <p><strong>E-posta:</strong> <?= esc_html($musteri->email) ?></p>
    </div>
    
    <h2>İşlem Geçmişi</h2>
    <table class="wp-list-table widefat fixed striped">
        <thead>
            <tr>
                <th>Tarih</th>
                <th>Tür</th>
                <th>Tutar</th>
                <th>Açıklama</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($islemler as $i): ?>
            <tr>
                <td><?= date('d.m.Y', strtotime($i->tarih)) ?></td>
                <td><?= $i->tur == 'borç' ? '<span style="color:red">Borç</span>' : '<span style="color:green">Alacak</span>' ?></td>
                <td><?= number_format($i->tutar, 2) ?> TL</td>
                <td><?= esc_html($i->aciklama) ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>