<div class="wrap">
    <h1>İşlem Yönetimi</h1>
    
    <?php
    // İşlem ekleme
    if (isset($_POST['islem_ekle'])) {
        CariFlow_DB::add_islem($_POST);
    }
    ?>
    
    <!-- İşlem Formu -->
    <form method="post">
        <h2>Yeni İşlem</h2>
        <select name="musteri_id" required>
            <?php foreach (CariFlow_DB::get_musteriler() as $musteri): ?>
            <option value="<?= $musteri->id ?>">
                <?= esc_html($musteri->ad . ' ' . $musteri->soyad) ?>
            </option>
            <?php endforeach; ?>
        </select>
        
        <select name="tur" required>
            <option value="borç">Borç</option>
            <option value="alacak">Alacak</option>
        </select>
        
        <input type="number" step="0.01" name="tutar" placeholder="Tutar" required>
        <textarea name="aciklama" placeholder="Açıklama"></textarea>
        <button type="submit" name="islem_ekle">Kaydet</button>
    </form>
    
    <!-- İşlem Listesi -->
    <table class="wp-list-table widefat fixed striped">
        <!-- ... (müşteri listesine benzer şekilde) ... -->
    </table>
</div>