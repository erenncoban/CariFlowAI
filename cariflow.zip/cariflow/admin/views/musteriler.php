<div class="wrap">
    <h1>Müşteri Yönetimi</h1>
    
    <?php
    global $wpdb;
    
    // Müşteri ekleme
    if (isset($_POST['musteri_ekle'])) {
        CariFlow_DB::add_musteri($_POST);
    }
    
    // Müşteri silme
    if (isset($_GET['sil'])) {
        CariFlow_DB::delete_musteri($_GET['sil']);
    }
    ?>
    
    <!-- Müşteri Ekleme Formu -->
    <form method="post">
        <h2>Yeni Müşteri</h2>
        <input type="text" name="ad" placeholder="Ad" required>
        <input type="text" name="soyad" placeholder="Soyad" required>
        <input type="text" name="telefon" placeholder="Telefon">
        <input type="email" name="email" placeholder="E-posta">
        <button type="submit" name="musteri_ekle">Kaydet</button>
    </form>
    
    <!-- Müşteri Listesi -->
    <table class="wp-list-table widefat fixed striped">
        <thead>
            <tr>
                <th>ID</th>
                <th>Ad</th>
                <th>Soyad</th>
                <th>Telefon</th>
                <th>İşlemler</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach (CariFlow_DB::get_musteriler() as $musteri): ?>
            <tr>
                <td><?= $musteri->id ?></td>
                <td><?= esc_html($musteri->ad) ?></td>
                <td><?= esc_html($musteri->soyad) ?></td>
                <td><?= esc_html($musteri->telefon) ?></td>
                <td>
                    <a href="?page=cariflow-detay&id=<?= $musteri->id ?>">Detay</a>
                    <a href="?page=cariflow-musteriler&sil=<?= $musteri->id ?>" onclick="return confirm('Silinsin mi?')">Sil</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>