<?php
class CariFlow_Admin {
    public static function init() {
        add_menu_page(
            'CariFlow', 
            'CariFlow', 
            'manage_options', 
            'cariflow', 
            [__CLASS__, 'ana_sayfa'],
            'dashicons-money-alt'
        );
        
        add_submenu_page(
            'cariflow',
            'Müşteriler',
            'Müşteriler',
            'manage_options',
            'cariflow-musteriler',
            [__CLASS__, 'musteri_listele']
        );
        
        add_submenu_page(
        'cariflow',
        'İşlem Ekle',
        'İşlem Ekle',
        'manage_options',
        'cariflow-islem-ekle',
        [__CLASS__, 'islem_ekle']
    );
        
        //Devamm
        add_submenu_page('cariflow', 'İşlemler', 'İşlemler', 'manage_options', 'cariflow-islemler', [__CLASS__, 'islem_ekle']);
        
        add_submenu_page('cariflow', 'Raporlar', 'Raporlar', 'manage_options', 'cariflow-raporlar', [__CLASS__, 'raporlar']);
        
        add_submenu_page(null, 'Müşteri Detay', 'Müşteri Detay', 'manage_options', 'cariflow-detay', function() {
        include __DIR__.'/views/musteri-detay.php';
    });
    }

    public static function ana_sayfa() {
        echo '<div class="wrap"><h1>CariFlow Yönetim Paneli</h1>';
        echo '<p>Hoş geldiniz! Sol menüden işlemleri seçebilirsiniz.</p></div>';
    }

    public static function musteri_listele() {
        global $wpdb;
        
        // EKLEME FORMUNU İŞLE
        if (isset($_POST['musteri_ekle'])) {
            $wpdb->insert("{$wpdb->prefix}cariflow_musteriler", [
                'ad' => sanitize_text_field($_POST['ad']),
                'soyad' => sanitize_text_field($_POST['soyad']),
                'telefon' => sanitize_text_field($_POST['telefon']),
                'email' => sanitize_email($_POST['email'])
            ]);
            echo '<div class="notice notice-success"><p>Müşteri eklendi!</p></div>';
        }
        
        // MÜŞTERİ LİSTESİ
        $musteriler = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}cariflow_musteriler");
        ?>
        <div class="wrap">
            <h1>Müşteri Yönetimi</h1>
            
            <form method="post">
                <h2>Yeni Müşteri</h2>
                <input type="text" name="ad" placeholder="Ad" required>
                <input type="text" name="soyad" placeholder="Soyad" required>
                <input type="text" name="telefon" placeholder="Telefon">
                <input type="email" name="email" placeholder="E-posta">
                <button type="submit" name="musteri_ekle" class="button button-primary">Kaydet</button>
            </form>
            
            <h2>Müşteri Listesi</h2>
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th>ID</th><th>Ad</th><th>Soyad</th><th>Telefon</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($musteriler as $m): ?>
                    <tr>
                        <td><?= $m->id ?></td>
                        <td><?= esc_html($m->ad) ?></td>
                        <td><?= esc_html($m->soyad) ?></td>
                        <td><?= esc_html($m->telefon) ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php
    }
    
    
    //İŞLEM KODLARI
    public static function islem_ekle() {
        global $wpdb;
        
        // İşlem ekleme formu
        if (isset($_POST['islem_ekle'])) {
            $wpdb->insert("{$wpdb->prefix}cariflow_islemler", [
                'musteri_id' => intval($_POST['musteri_id']),
                'tur' => sanitize_text_field($_POST['tur']),
                'tutar' => floatval($_POST['tutar']),
                'aciklama' => sanitize_textarea_field($_POST['aciklama'])
            ]);
            echo '<div class="notice notice-success"><p>İşlem eklendi!</p></div>';
        }
        
        $musteriler = $wpdb->get_results("SELECT id, ad, soyad FROM {$wpdb->prefix}cariflow_musteriler");
        ?>
        <div class="wrap">
            <h1>Yeni İşlem Ekle</h1>
            
            <form method="post">
                <div>
                    <label>Müşteri:</label>
                    <select name="musteri_id" required>
                        <?php foreach ($musteriler as $m): ?>
                        <option value="<?= $m->id ?>">
                            <?= esc_html($m->ad.' '.$m->soyad) ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                
                <div>
                    <label>İşlem Türü:</label>
                    <select name="tur" required>
                        <option value="borç">Borç</option>
                        <option value="alacak">Alacak</option>
                    </select>
                </div>
                
                <div>
                    <label>Tutar:</label>
                    <input type="number" step="0.01" name="tutar" required>
                </div>
                
                <div>
                    <label>Açıklama:</label>
                    <textarea name="aciklama"></textarea>
                </div>
                
                <button type="submit" name="islem_ekle" class="button button-primary">Kaydet</button>
            </form>
        </div>
        <?php
    }
}
    

public static function raporlar() {
    global $wpdb;
    
    $toplam_borc = $wpdb->get_var(
        "SELECT SUM(tutar) FROM {$wpdb->prefix}cariflow_islemler WHERE tur = 'borç'"
    );
    
    $toplam_alacak = $wpdb->get_var(
        "SELECT SUM(tutar) FROM {$wpdb->prefix}cariflow_islemler WHERE tur = 'alacak'"
    );
    ?>
    <div class="wrap">
        <h1>Finansal Raporlar</h1>
        
        <div class="card">
            <h3>Genel Durum</h3>
            <p><strong>Toplam Borç:</strong> <?= number_format($toplam_borc, 2) ?> TL</p>
            <p><strong>Toplam Alacak:</strong> <?= number_format($toplam_alacak, 2) ?> TL</p>
            <p><strong>Bakiye:</strong> 
                <?= number_format($toplam_alacak - $toplam_borc, 2) ?> TL
                (<?= ($toplam_alacak > $toplam_borc) ? 'Alacak' : 'Borç' ?>)
            </p>
        </div>
    </div>
    <?php
}
    
    
}