<?php
if (!class_exists('CariFlow_DB')) {
    class CariFlow_DB {
        public static function create_tables() {
            global $wpdb;
            
            $charset = $wpdb->get_charset_collate() . ' ENGINE=InnoDB';
            
            // 1. Tablo: Müşteriler
            $sql = "CREATE TABLE {$wpdb->prefix}cariflow_musteriler (
                id INT NOT NULL AUTO_INCREMENT,
                ad VARCHAR(100) NOT NULL,
                soyad VARCHAR(100) NOT NULL,
                telefon VARCHAR(20),
                email VARCHAR(100),
                PRIMARY KEY (id)
            ) $charset;";
            
            require_once ABSPATH . 'wp-admin/includes/upgrade.php';
            dbDelta($sql);
            
            // 2. Tablo: İşlemler
            $sql = "CREATE TABLE {$wpdb->prefix}cariflow_islemler (
                id INT NOT NULL AUTO_INCREMENT,
                musteri_id INT NOT NULL,
                tur ENUM('borç', 'alacak') NOT NULL,
                tutar DECIMAL(10,2) NOT NULL,
                aciklama TEXT,
                tarih DATETIME DEFAULT CURRENT_TIMESTAMP,
                PRIMARY KEY (id),
                FOREIGN KEY (musteri_id) REFERENCES {$wpdb->prefix}cariflow_musteriler(id) ON DELETE CASCADE
            ) $charset;";
            
            dbDelta($sql);
        }
    }
}