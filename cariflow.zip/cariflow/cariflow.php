<?php
/**
Plugin Name: CariFlow FİNANS CRM MODÜLÜ
Plugin URI: https://www.pancreative.co
Description: Bu modül müşterilerinize ait carii borç takibi yapabilmenizi sağlar.
Version: 2.0.1
Author: Pan Creative Agency, Eren Çoban
Author URI: https://www.pancreative.co
License: GNU
*/

defined('ABSPATH') || exit;


// include dosyalarını doğru sırayla yükle
require_once plugin_dir_path(__FILE__) . 'includes/class-db.php';

// Aktivasyon hook'unu güncelle
register_activation_hook(__FILE__, function() {
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    CariFlow_DB::create_tables();
});


// Veritabanı tablolarını oluştur
register_activation_hook(__FILE__, 'cariflow_db_setup');
function cariflow_db_setup() {
    require_once(plugin_dir_path(__FILE__) . 'includes/class-db.php');
    CariFlow_DB::create_tables();
}

// Admin menüsünü yükle
add_action('admin_menu', 'cariflow_admin_menu');
function cariflow_admin_menu() {
    require_once(plugin_dir_path(__FILE__) . 'admin/admin-functions.php');
    CariFlow_Admin::init();
}

// Frontend kısa kodunu ekle
add_shortcode('cari_hesabim', 'cariflow_musteri_paneli');
function cariflow_musteri_paneli() {
    require_once(plugin_dir_path(__FILE__) . 'public/public-functions.php');
    return CariFlow_Public::render();
}

// CSS/JS dosyalarını yükle
add_action('admin_enqueue_scripts', 'cariflow_admin_assets');
function cariflow_admin_assets() {
    wp_enqueue_style('cariflow-admin-css', plugins_url('admin/admin-style.css', __FILE__));
    wp_enqueue_script('cariflow-admin-js', plugins_url('admin/admin-ajax.js', __FILE__), array('jquery'), '1.0', true);
}
?>